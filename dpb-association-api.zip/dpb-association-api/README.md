# DPB Association API

Backend for the **Market Association Record App** — a mobile app used by the committee of
a large flower-market association (Dadar Phool Bazaar / DPB Mandal) to keep its register of
**shops and people** and, in a later phase, its money (contributions, funds, event
spending).

Only the committee (5–6 people) signs in; shopkeepers never use the app. There are three
roles — **Admin**, **Collector**, **Viewer** — determined by the phone number that signs
in and re-checked on the server for every request.

This repository is the **v1** scope: the **register** (shops, people, their links) plus the
authentication and committee foundations it needs. The money module is a later phase and is
not part of this codebase yet.

---

## Tech stack

| Concern | Choice |
| --- | --- |
| Language / runtime | Java 21 |
| Framework | Spring Boot 4.1 (Spring Security, Spring Data JPA) |
| Database | PostgreSQL 16 |
| Migrations | Flyway (schema is migration-owned; Hibernate runs in `validate` mode) |
| Auth | Stateless JWT (jjwt) + bcrypt PINs |
| Object storage | AWS SDK v2 (S3) — MinIO in dev, S3 in prod; presigned upload/download |
| Build | Maven wrapper (`./mvnw`), Lombok |

---

## Quick start

**Prerequisites:** Docker, JDK 21, and the Maven wrapper (included).

```bash
# 1. Start Postgres + MinIO
docker compose up -d

# 2. Run the API (Flyway migrates on boot; the media bucket is auto-created)
export JAVA_HOME=<your JDK 21 home>
./mvnw spring-boot:run
```

The API starts on **`http://localhost:8080`**, base path **`/api/v1`**.

- Postgres → `localhost:5432` (db/user/pass all `dpb`)
- MinIO → API `localhost:9000`, console `localhost:9001` (`minioadmin` / `minioadmin`)

A **first admin** is seeded so you can sign in. They have **no PIN yet** and set one on
first sign-in via a one-time code (see below).

### Build & test

```bash
./mvnw compile        # compile
./mvnw test           # boots the full context against Postgres and runs the tests
./mvnw spring-boot:run # run locally
```

---

## Authentication

Sign-in is **phone number + a 4-digit M-PIN**. The number decides the role; there is no
role picker. Tokens are stateless JWTs: a short-lived **access token** (sent as
`Authorization: Bearer <token>`) and a longer-lived **refresh token** that is rotated on
use. A user's rights are re-loaded from the database on every request, so a role change or
removal takes effect immediately.

### First sign-in (set a PIN)

A newly added committee member has no PIN. They receive a one-time code by SMS, verify it,
and set their PIN. **In development there is no SMS** — the code is printed to the app
console (look for a `DEV OTP` line).

```bash
BASE=http://localhost:8080/api/v1
PHONE=8451963620   # the seeded admin

# Is this number on the committee? (greets by name; tells you if a PIN is set)
curl -s -X POST $BASE/auth/phone -H 'Content-Type: application/json' \
  -d "{\"phone\":\"$PHONE\"}"

# Request a first-login code (printed to the app console in dev)
curl -s -X POST $BASE/auth/otp/request -H 'Content-Type: application/json' \
  -d "{\"phone\":\"$PHONE\",\"purpose\":\"FIRST_LOGIN\"}"

# Verify the code -> returns a short-lived resetToken
curl -s -X POST $BASE/auth/otp/verify -H 'Content-Type: application/json' \
  -d "{\"phone\":\"$PHONE\",\"code\":\"123456\"}"

# Set the PIN with that resetToken -> returns access + refresh tokens
curl -s -X POST $BASE/auth/pin/set -H 'Content-Type: application/json' \
  -d '{"resetToken":"<resetToken>","newPin":"1947"}'
```

### Everyday sign-in

```bash
curl -s -X POST $BASE/auth/login -H 'Content-Type: application/json' \
  -d "{\"phone\":\"$PHONE\",\"pin\":\"1947\"}"
# -> { "accessToken": "...", "refreshToken": "...", "tokenType": "Bearer", "expiresInSeconds": 2700 }
```

Use the access token on subsequent calls:

```bash
TOKEN=<accessToken>
curl -s $BASE/me -H "Authorization: Bearer $TOKEN"
# -> { "id": "...", "name": "Ishwar", "role": "ADMIN" }
```

**Notes**
- Five wrong PINs lock the account for 15 minutes (`423`).
- Forgotten PIN and change-PIN both use the same OTP → set-PIN flow (`purpose: PIN_RESET`).
- Refreshing rotates the token: the old refresh token is revoked. Multiple devices are
  allowed (each gets its own refresh token).

---

## API reference

Base path: **`/api/v1`**. All responses are JSON. Errors have the shape
`{ "code": "...", "message": "..." }`. Protected routes return `401` without a valid token
and `403` when the role is not allowed.

### Auth

| Method & path | Auth | Purpose |
| --- | --- | --- |
| `POST /auth/phone` | public | Check committee membership; greet by first name; report whether a PIN is set |
| `POST /auth/login` | public | Phone + PIN → token pair (`401` wrong, `423` locked, `409` PIN not set) |
| `POST /auth/otp/request` | public | Send a one-time code (`FIRST_LOGIN` or `PIN_RESET`) |
| `POST /auth/otp/verify` | public | Verify the code → short-lived reset token |
| `POST /auth/pin/set` | public | Set a new PIN with a reset token → token pair |
| `POST /auth/token/refresh` | public | Rotate: revoke the old refresh token, issue a new pair |
| `POST /auth/logout` | public | Revoke this device's refresh token |
| `POST /auth/verify-pin` | bearer | Re-check the PIN (used to unlock the app after inactivity) |
| `GET  /me` | bearer | The signed-in user's id, name, role |

### Shops

| Method & path | Roles | Purpose |
| --- | --- | --- |
| `POST /shops` | admin, collector | Register a shop **and its owner** in one atomic step (owner = an existing member or a new one) |
| `GET  /shops` | all | Search + list. Query params: `query`, `lane`, `page`, `size` |
| `GET  /shops/{id}` | all | Shop detail + the people at the shop |
| `PATCH /shops/{id}` | admin, collector | Edit shop number / business name / lane / tenancy |
| `DELETE /shops/{id}` | admin | Soft-delete the shop and unlink everyone |
| `POST /shops/{id}/links` | admin, collector | Add a **renter** or **staff** (existing or new person) |
| `POST /shops/{id}/transfer` | admin | Transfer the licence to a new owner; records the former holder |
| `DELETE /links/{linkId}` | admin | Remove a renter/staff link (owner links cannot be removed here) |

`GET /shops?query=` searches shop number, business name, or any linked person's name/phone
(case-insensitive). `lane` filters by lane. The list is server-paginated
(`{ content, page, size, totalElements, totalPages }`).

### People & media

| Method & path | Roles | Purpose |
| --- | --- | --- |
| `POST /media/upload-url` | admin, collector | Get a presigned URL to upload a photo/Aadhaar image directly to storage |
| `POST /people` | admin, collector | Add a member with at least one renter/staff link |
| `GET  /people` | all | Search + list. Query params: `query`, `role`, `page`, `size` |
| `GET  /people/{id}` | all | Member profile: details, shops & roles, a signed photo URL |
| `PATCH /people/{id}` | admin, collector | Edit name / phone / WhatsApp / address |
| `POST /people/{id}/links` | admin, collector | Link the member to another shop (renter/staff) |
| `DELETE /people/{id}` | admin | Soft-delete the member and unlink |
| `GET  /people/{id}/photo` | all | Short-lived signed URL for the member photo |
| `PUT  /people/{id}/photo` | admin, collector | Replace the member photo (retake) |
| `GET  /people/{id}/aadhaar/{side}` | **admin** | Signed URL for the Aadhaar image (`FRONT`/`BACK`); **the access is logged** |
| `PUT  /people/{id}/aadhaar` | admin, collector | Replace one side of the Aadhaar (re-capture); logged |

**Image upload flow.** The client first calls `POST /media/upload-url` for each image, uploads
the bytes straight to storage with the returned presigned URL, then submits the person with
the returned `key`s. The API never proxies image bytes — it only mints presigned URLs and
stores the keys.

**Aadhaar is the strictest data in the app.** A collector can capture it but can never view
it again — only an admin can open a stored Aadhaar image, always through a short-lived
signed URL, and every view and re-capture is recorded in an access log. The member photo,
by contrast, is viewable by anyone signed in.

`GET /people?query=` searches name, phone, or shop number; `role` filters by
`OWNER` / `RENTER` / `STAFF`.

### Committee (admin only)

Managing who can sign in and with what role.

| Method & path | Purpose |
| --- | --- |
| `GET /committee` | List everyone who can sign in (active first, then removed members) |
| `GET /committee/{id}` | One member's detail |
| `POST /committee` | Add a member (`name`, `phone`, `role`); they set their PIN on first sign-in |
| `PATCH /committee/{id}` | Change a member's role (takes effect on their next request) |
| `POST /committee/{id}/reset-pin` | Clear a member's PIN and sign them out; they set a new one via the code flow |
| `DELETE /committee/{id}` | Remove a member (soft): they can no longer sign in |

Two safeguards always hold: you cannot change or remove **yourself** (another admin must),
and the association must always keep **at least one admin**. Removing a member frees their
phone number so it can be re-added later.

---

## Roles & permissions

| | Admin | Collector | Viewer |
| --- | :---: | :---: | :---: |
| Read shops & people | ✅ | ✅ | ✅ |
| Register / edit shops & people, add renter/staff, capture images | ✅ | ✅ | — |
| Transfer a licence, remove a link, delete a shop/person | ✅ | — | — |
| View a stored Aadhaar image | ✅ | — | — |

Permissions are enforced on the server for every request; the client only hides buttons.

**Core rules in the register**

- A shop always has exactly **one owner**. Owners are created only through shop
  registration or a licence transfer, and are never removed directly — only replaced by a
  transfer.
- A person and a shop are linked by a role: **Owner**, **Renter**, or **Staff**. A shop has
  at most one owner and one renter, and any number of staff. A person may hold roles at
  several shops (e.g. owner of one, renter of another).
- Every member must be linked to at least one shop when created, but may become "not
  linked" later if their last renter/staff link is removed.
- Shop numbers are unique across the market (case-insensitive); member phone numbers are
  unique.
- Nothing is hard-deleted: shops and people are **soft-deleted** (hidden, recoverable), and
  a soft-delete frees the shop number / phone so a corrected record can be created.

---

## Project structure

Packages are organised **by feature**; inside each feature, classes are grouped by kind
(`entity`, `repo`, `enums`, `dto`, `service`, `controller`). `common` and `security` are
shared infrastructure.

```
src/main/java/in/dpbmandal/api/
├── DpbAssociationApiApplication.java
├── common/         # base entity + JPA auditing, config properties, paged response, error handling
├── security/       # JWT filter, security config, current-user helper
├── committee/      # committee users (the login accounts)
├── person/         # market people (register) + media (photo/Aadhaar) endpoints
├── shop/           # shops
├── link/           # person <-> shop links (+ audit)
├── audit/          # Aadhaar access log
├── media/          # S3/MinIO presigned upload + signed reads
└── auth/           # sign-in, tokens, OTP

src/main/resources/
├── application.yaml
└── db/migration/   # Flyway migrations (V1__..., V2__...)

compose.yaml        # Postgres + MinIO for local dev
```

**Conventions**

- **DTOs are Java `record`s** (both requests and responses); entities are classes and are
  never returned directly at the API boundary.
- **Services are single concrete classes** (no interface + `Impl`).
- Enums are stored as `varchar` with a `CHECK` constraint (not native Postgres enums).
- IDs are UUIDs generated by the app.
- Uniqueness is enforced only among active (non-deleted) rows via partial unique indexes.
- Schema changes are always a **new Flyway migration** — never edit an applied one, and
  never let Hibernate alter the schema.

---

## Data model (v1)

| Table | What it holds |
| --- | --- |
| `committee_user` | Login accounts: phone, name, role, PIN hash, lockout state |
| `person` | Market people: name, phone, WhatsApp, address, photo/Aadhaar keys, consent |
| `shop` | Shops: number, business name, lane, tenancy, former-holder info |
| `shop_link` | Person↔shop with a role (owner/renter/staff) |
| `shop_link_audit` | History of link add/remove |
| `aadhaar_access_log` | Every admin view / re-capture of an Aadhaar image |
| `refresh_token` | Revocable refresh tokens (one row per device) |
| `otp_request` | First-login and PIN-reset one-time codes |

---

## Configuration

Settings live in `src/main/resources/application.yaml` and can be overridden by environment
variables. Sensible dev defaults are built in.

| Variable | Meaning | Dev default |
| --- | --- | --- |
| `DB_URL`, `DB_USER`, `DB_PASSWORD` | Postgres connection | `jdbc:postgresql://localhost:5432/dpb`, `dpb`, `dpb` |
| `APP_JWT_SECRET` | HMAC signing secret for JWTs (**set a strong value in production**) | a dev-only placeholder |
| `S3_ENDPOINT`, `S3_REGION` | Object-storage endpoint/region | `http://localhost:9000`, `us-east-1` |
| `S3_ACCESS_KEY`, `S3_SECRET_KEY` | Object-storage credentials | `minioadmin` / `minioadmin` |
| `S3_BUCKET` | Media bucket | `dpb-media` |

Other tunables (token lifetimes, OTP length/expiry, PIN lockout, presign expiry) are under
the `app.*` keys in `application.yaml`.

**Production notes**

- Set a real `APP_JWT_SECRET` and object-storage credentials.
- Enable server-side encryption (SSE) on the media bucket for at-rest encryption of Aadhaar
  images.
- Wire a real SMS provider for OTP delivery (dev logs the code to the console); India
  requires DLT registration for transactional SMS.

---

## Development notes

- **Migrations:** add a new `V<n>__description.sql` under `db/migration`. The app validates
  the JPA entities against the schema on boot, so entities and migrations must stay in sync.
- **OTP in dev:** printed to the app console (`DEV OTP` line) instead of being sent by SMS.
- **Media in dev:** MinIO stands in for S3; the bucket is created automatically on startup.
- **Reset local state:** `docker compose down -v` removes the Postgres and MinIO volumes for
  a clean slate (Flyway re-seeds the first admin on the next boot).
