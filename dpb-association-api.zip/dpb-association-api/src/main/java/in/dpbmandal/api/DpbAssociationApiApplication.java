package in.dpbmandal.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.security.autoconfigure.UserDetailsServiceAutoConfiguration;

// Exclude Boot's default in-memory user; auth is handled by our JWT filter.
@SpringBootApplication(exclude = UserDetailsServiceAutoConfiguration.class)
public class DpbAssociationApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(DpbAssociationApiApplication.class, args);
    }

}
