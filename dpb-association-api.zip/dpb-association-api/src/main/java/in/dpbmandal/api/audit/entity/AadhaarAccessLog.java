package in.dpbmandal.api.audit.entity;

import in.dpbmandal.api.audit.enums.AadhaarAction;
import in.dpbmandal.api.audit.enums.AadhaarSide;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "aadhaar_access_log")
public class AadhaarAccessLog {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(nullable = false, updatable = false)
    private UUID id;

    @Column(name = "person_id", nullable = false)
    private UUID personId;

    @Column(name = "committee_user_id", nullable = false)
    private UUID committeeUserId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AadhaarAction action;

    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private AadhaarSide side;

    @Column(name = "accessed_at", nullable = false)
    private Instant accessedAt;
}
