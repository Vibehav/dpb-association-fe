package in.dpbmandal.api.audit.enums;

public enum AadhaarAction {
    VIEW,
    RECAPTURE
}
