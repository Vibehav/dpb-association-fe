package in.dpbmandal.api.audit.enums;

public enum AadhaarSide {
    FRONT,
    BACK
}
