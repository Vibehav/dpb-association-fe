package in.dpbmandal.api.audit.repo;

import in.dpbmandal.api.audit.entity.AadhaarAccessLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface AadhaarAccessLogRepository extends JpaRepository<AadhaarAccessLog, UUID> {
}
