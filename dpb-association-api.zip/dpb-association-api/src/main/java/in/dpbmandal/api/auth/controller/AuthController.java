package in.dpbmandal.api.auth.controller;

import in.dpbmandal.api.auth.dto.LoginRequest;
import in.dpbmandal.api.auth.dto.LogoutRequest;
import in.dpbmandal.api.auth.dto.OtpRequestRequest;
import in.dpbmandal.api.auth.dto.OtpVerifyRequest;
import in.dpbmandal.api.auth.dto.OtpVerifyResponse;
import in.dpbmandal.api.auth.dto.PhoneCheckRequest;
import in.dpbmandal.api.auth.dto.PhoneCheckResponse;
import in.dpbmandal.api.auth.dto.PinSetRequest;
import in.dpbmandal.api.auth.dto.RefreshRequest;
import in.dpbmandal.api.auth.dto.TokenPairResponse;
import in.dpbmandal.api.auth.dto.VerifyPinRequest;
import in.dpbmandal.api.auth.service.AuthService;
import in.dpbmandal.api.security.AuthPrincipal;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/phone")
    public PhoneCheckResponse phone(@Valid @RequestBody PhoneCheckRequest req) {
        return authService.checkPhone(req.phone());
    }

    @PostMapping("/login")
    public TokenPairResponse login(@Valid @RequestBody LoginRequest req) {
        return authService.login(req.phone(), req.pin());
    }

    @PostMapping("/otp/request")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void otpRequest(@Valid @RequestBody OtpRequestRequest req) {
        authService.requestOtp(req.phone(), req.purpose());
    }

    @PostMapping("/otp/verify")
    public OtpVerifyResponse otpVerify(@Valid @RequestBody OtpVerifyRequest req) {
        return authService.verifyOtp(req.phone(), req.code());
    }

    @PostMapping("/pin/set")
    public TokenPairResponse pinSet(@Valid @RequestBody PinSetRequest req) {
        return authService.setPin(req.resetToken(), req.newPin());
    }

    @PostMapping("/token/refresh")
    public TokenPairResponse refresh(@Valid @RequestBody RefreshRequest req) {
        return authService.refresh(req.refreshToken());
    }

    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(@Valid @RequestBody LogoutRequest req) {
        authService.logout(req.refreshToken());
    }

    @PostMapping("/verify-pin")
    public ResponseEntity<Void> verifyPin(@AuthenticationPrincipal AuthPrincipal principal,
                                          @Valid @RequestBody VerifyPinRequest req) {
        authService.verifyPin(principal.userId(), req.pin());
        return ResponseEntity.noContent().build();
    }
}
