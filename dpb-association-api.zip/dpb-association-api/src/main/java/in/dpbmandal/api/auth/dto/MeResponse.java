package in.dpbmandal.api.auth.dto;

import in.dpbmandal.api.committee.enums.Role;

import java.util.UUID;

public record MeResponse(UUID id, String name, Role role) {
}
