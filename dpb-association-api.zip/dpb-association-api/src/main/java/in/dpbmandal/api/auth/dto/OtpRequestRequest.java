package in.dpbmandal.api.auth.dto;

import in.dpbmandal.api.auth.enums.OtpPurpose;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public record OtpRequestRequest(
        @NotBlank @Pattern(regexp = "\\d{10}", message = "must be 10 digits") String phone,
        @NotNull OtpPurpose purpose) {
}
