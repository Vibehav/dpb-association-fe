package in.dpbmandal.api.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record OtpVerifyRequest(
        @NotBlank @Pattern(regexp = "\\d{10}", message = "must be 10 digits") String phone,
        @NotBlank @Pattern(regexp = "\\d{4,8}", message = "invalid code") String code) {
}
