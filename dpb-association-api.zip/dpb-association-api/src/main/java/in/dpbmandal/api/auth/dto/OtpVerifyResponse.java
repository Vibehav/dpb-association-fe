package in.dpbmandal.api.auth.dto;

/** A short-lived token that authorizes exactly one {@code /auth/pin/set} call. */
public record OtpVerifyResponse(String resetToken) {
}
