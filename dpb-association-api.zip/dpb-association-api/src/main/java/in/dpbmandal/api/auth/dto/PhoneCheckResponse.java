package in.dpbmandal.api.auth.dto;

/**
 * {@code onCommittee=false} → firstName/pinSet are null. Otherwise the first name
 * (to greet) and whether the user has set a PIN (false → first-login OTP flow).
 */
public record PhoneCheckResponse(boolean onCommittee, String firstName, Boolean pinSet) {
}
