package in.dpbmandal.api.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record PinSetRequest(
        @NotBlank String resetToken,
        @NotBlank @Pattern(regexp = "\\d{4}", message = "must be a 4-digit PIN") String newPin) {
}
