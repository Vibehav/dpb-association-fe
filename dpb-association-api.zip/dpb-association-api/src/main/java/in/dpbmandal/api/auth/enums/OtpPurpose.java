package in.dpbmandal.api.auth.enums;

public enum OtpPurpose {
    FIRST_LOGIN,
    PIN_RESET
}
