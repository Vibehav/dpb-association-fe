package in.dpbmandal.api.auth.repo;

import in.dpbmandal.api.auth.entity.OtpRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface OtpRequestRepository extends JpaRepository<OtpRequest, UUID> {

    /** Most recent request for throttling. */
    Optional<OtpRequest> findTopByCommitteeUserIdOrderByCreatedAtDesc(UUID committeeUserId);

    /** Most recent still-usable (unconsumed) code to verify against. */
    Optional<OtpRequest> findTopByCommitteeUserIdAndConsumedAtIsNullOrderByCreatedAtDesc(UUID committeeUserId);
}
