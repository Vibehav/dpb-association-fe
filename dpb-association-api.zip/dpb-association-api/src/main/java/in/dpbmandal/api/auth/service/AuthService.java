package in.dpbmandal.api.auth.service;

import in.dpbmandal.api.auth.dto.MeResponse;
import in.dpbmandal.api.auth.dto.OtpVerifyResponse;
import in.dpbmandal.api.auth.dto.PhoneCheckResponse;
import in.dpbmandal.api.auth.dto.TokenPairResponse;
import in.dpbmandal.api.auth.entity.OtpRequest;
import in.dpbmandal.api.auth.entity.RefreshToken;
import in.dpbmandal.api.auth.enums.OtpPurpose;
import in.dpbmandal.api.auth.repo.OtpRequestRepository;
import in.dpbmandal.api.auth.repo.RefreshTokenRepository;
import in.dpbmandal.api.committee.entity.CommitteeUser;
import in.dpbmandal.api.committee.repo.CommitteeUserRepository;
import in.dpbmandal.api.common.AppProperties;
import in.dpbmandal.api.common.exception.ApiException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;
import java.util.HexFormat;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final CommitteeUserRepository userRepo;
    private final RefreshTokenRepository refreshRepo;
    private final OtpRequestRepository otpRepo;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final OtpSender otpSender;
    private final AppProperties props;

    private final SecureRandom random = new SecureRandom();

    // ---- phone check --------------------------------------------------------

    @Transactional(readOnly = true)
    public PhoneCheckResponse checkPhone(String phone) {
        return userRepo.findByPhoneAndDeletedAtIsNull(phone)
                .filter(CommitteeUser::isActive)
                .map(u -> new PhoneCheckResponse(true, firstName(u.getName()), u.isPinSet()))
                .orElseGet(() -> new PhoneCheckResponse(false, null, null));
    }

    // ---- login --------------------------------------------------------------

    // noRollbackFor: a wrong-PIN ApiException must NOT undo the failed-attempt increment.
    @Transactional(noRollbackFor = ApiException.class)
    public TokenPairResponse login(String phone, String pin) {
        CommitteeUser user = activeUserByPhone(phone);
        ensureNotLocked(user);
        if (!user.isPinSet()) {
            throw ApiException.conflict("pin_not_set", "Set your PIN first via the one-time code");
        }
        if (!encoder.matches(pin, user.getPinHash())) {
            registerPinFailure(user);
            throw wrongPin(user);
        }
        clearPinFailures(user);
        return issueTokenPair(user);
    }

    // ---- otp: request / verify ---------------------------------------------

    @Transactional
    public void requestOtp(String phone, OtpPurpose purpose) {
        CommitteeUser user = activeUserByPhone(phone);
        otpRepo.findTopByCommitteeUserIdOrderByCreatedAtDesc(user.getId()).ifPresent(last -> {
            Instant earliestNext = last.getCreatedAt().plus(props.getOtp().getResendThrottle());
            if (Instant.now().isBefore(earliestNext)) {
                throw ApiException.tooManyRequests("otp_throttled", "Please wait before requesting another code");
            }
        });

        String code = randomDigits(props.getOtp().getLength());
        OtpRequest otp = new OtpRequest();
        otp.setCommitteeUserId(user.getId());
        otp.setCodeHash(encoder.encode(code));
        otp.setPurpose(purpose);
        otp.setExpiresAt(Instant.now().plus(props.getOtp().getTtl()));
        otpRepo.save(otp);

        otpSender.send(phone, code);
        System.out.println(code);
    }

    @Transactional
    public OtpVerifyResponse verifyOtp(String phone, String code) {
        CommitteeUser user = activeUserByPhone(phone);
        OtpRequest otp = otpRepo
                .findTopByCommitteeUserIdAndConsumedAtIsNullOrderByCreatedAtDesc(user.getId())
                .orElseThrow(() -> ApiException.badRequest("otp_invalid", "No valid code — request a new one"));

        if (Instant.now().isAfter(otp.getExpiresAt())) {
            throw ApiException.badRequest("otp_expired", "Code expired — request a new one");
        }
        if (otp.getAttempts() >= props.getOtp().getMaxVerifyAttempts()) {
            throw ApiException.badRequest("otp_attempts_exhausted", "Too many attempts — request a new code");
        }
        if (!encoder.matches(code, otp.getCodeHash())) {
            otp.setAttempts(otp.getAttempts() + 1);
            otpRepo.save(otp);
            throw ApiException.badRequest("otp_invalid", "Incorrect code");
        }

        otp.setConsumedAt(Instant.now());
        otpRepo.save(otp);
        String issueResetToken = jwt.issueResetToken(user.getId());
        System.out.println(issueResetToken);
        return new OtpVerifyResponse(issueResetToken);
    }

    // ---- set pin (first-login / reset / change) -----------------------------

    @Transactional
    public TokenPairResponse setPin(String resetToken, String newPin) {
        UUID userId = jwt.parseResetToken(resetToken);
        CommitteeUser user = userRepo.findById(userId)
                .filter(u -> u.getDeletedAt() == null && u.isActive())
                .orElseThrow(() -> ApiException.unauthorized("invalid_reset_token", "User not available"));

        user.setPinHash(encoder.encode(newPin));
        user.setPinSet(true);
        clearPinFailures(user);
        return issueTokenPair(user);
    }

    // ---- refresh / logout ---------------------------------------------------

    @Transactional
    public TokenPairResponse refresh(String rawRefreshToken) {
        RefreshToken token = refreshRepo.findByTokenHash(sha256(rawRefreshToken))
                .orElseThrow(() -> ApiException.unauthorized("invalid_refresh", "Invalid refresh token"));
        if (token.getRevokedAt() != null || Instant.now().isAfter(token.getExpiresAt())) {
            throw ApiException.unauthorized("invalid_refresh", "Refresh token no longer valid");
        }
        CommitteeUser user = userRepo.findById(token.getCommitteeUserId())
                .filter(u -> u.getDeletedAt() == null && u.isActive())
                .orElseThrow(() -> ApiException.unauthorized("invalid_refresh", "User not available"));

        token.setRevokedAt(Instant.now());
        token.setLastUsedAt(Instant.now());
        refreshRepo.save(token);
        return issueTokenPair(user);
    }

    @Transactional
    public void logout(String rawRefreshToken) {
        refreshRepo.findByTokenHash(sha256(rawRefreshToken)).ifPresent(token -> {
            if (token.getRevokedAt() == null) {
                token.setRevokedAt(Instant.now());
                refreshRepo.save(token);
            }
        });
    }

    // ---- app-unlock verify-pin ---------------------------------------------

    @Transactional(noRollbackFor = ApiException.class)
    public void verifyPin(UUID userId, String pin) {
        CommitteeUser user = userRepo.findById(userId)
                .filter(u -> u.getDeletedAt() == null && u.isActive())
                .orElseThrow(() -> ApiException.unauthorized("unauthorized", "User not available"));
        ensureNotLocked(user);
        if (!encoder.matches(pin, user.getPinHash())) {
            registerPinFailure(user);
            throw wrongPin(user);
        }
        clearPinFailures(user);
    }

    // ---- me -----------------------------------------------------------------

    @Transactional(readOnly = true)
    public MeResponse me(UUID userId) {
        CommitteeUser user = userRepo.findById(userId)
                .filter(u -> u.getDeletedAt() == null && u.isActive())
                .orElseThrow(() -> ApiException.unauthorized("unauthorized", "User not available"));
        return new MeResponse(user.getId(), user.getName(), user.getRole());
    }

    // ---- helpers ------------------------------------------------------------

    private CommitteeUser activeUserByPhone(String phone) {
        return userRepo.findByPhoneAndDeletedAtIsNull(phone)
                .filter(CommitteeUser::isActive)
                .orElseThrow(() -> ApiException.notFound("not_on_committee", "This number is not on the committee"));
    }

    private void ensureNotLocked(CommitteeUser user) {
        if (user.getLockedUntil() != null && Instant.now().isBefore(user.getLockedUntil())) {
            throw ApiException.locked("pin_locked", "Too many wrong attempts. Try again later or reset your PIN");
        }
    }

    private void registerPinFailure(CommitteeUser user) {
        user.setFailedPinAttempts(user.getFailedPinAttempts() + 1);
        if (user.getFailedPinAttempts() >= props.getPin().getMaxAttempts()) {
            user.setLockedUntil(Instant.now().plus(props.getPin().getLockDuration()));
            user.setFailedPinAttempts(0);
        }
        userRepo.save(user);
    }

    private void clearPinFailures(CommitteeUser user) {
        user.setFailedPinAttempts(0);
        user.setLockedUntil(null);
        userRepo.save(user);
    }

    private ApiException wrongPin(CommitteeUser user) {
        if (user.getLockedUntil() != null && Instant.now().isBefore(user.getLockedUntil())) {
            return ApiException.locked("pin_locked", "Too many wrong attempts. Try again later or reset your PIN");
        }
        return ApiException.unauthorized("wrong_pin", "Incorrect PIN");
    }

    private TokenPairResponse issueTokenPair(CommitteeUser user) {
        String access = jwt.issueAccessToken(user);
        String rawRefresh = randomToken();
        RefreshToken rt = new RefreshToken();
        rt.setCommitteeUserId(user.getId());
        rt.setTokenHash(sha256(rawRefresh));
        rt.setExpiresAt(Instant.now().plus(props.getRefresh().getTtl()));
        refreshRepo.save(rt);
        return TokenPairResponse.bearer(access, rawRefresh, jwt.accessTtlSeconds());
    }

    private String firstName(String fullName) {
        String trimmed = fullName == null ? "" : fullName.trim();
        int sp = trimmed.indexOf(' ');
        return sp > 0 ? trimmed.substring(0, sp) : trimmed;
    }

    private String randomDigits(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }

    private String randomToken() {
        byte[] bytes = new byte[32];
        random.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private String sha256(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(md.digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 unavailable", e);
        }
    }
}
