package in.dpbmandal.api.auth.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Dev stub: logs the OTP to the console instead of sending an SMS. Replace with a
 * real provider before production (there is no other {@link OtpSender} bean yet).
 */
@Slf4j
@Component
public class ConsoleOtpSender implements OtpSender {

    @Override
    public void send(String phone, String code) {
        log.info("=== DEV OTP === +91{} -> {} (no SMS sent; console stub)", phone, code);
    }
}
