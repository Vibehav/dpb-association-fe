package in.dpbmandal.api.auth.service;

import in.dpbmandal.api.committee.entity.CommitteeUser;
import in.dpbmandal.api.common.AppProperties;
import in.dpbmandal.api.common.exception.ApiException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;

/**
 * Issues and parses the HS256 access token and the short-lived pin-set (reset) token.
 * The access token is identity + a snapshot of role/token-version; authorization is
 * still re-derived from the DB on every request (see JwtAuthFilter).
 */
@Service
public class JwtService {

    private static final String RESET_TYPE = "pin_set";

    private final SecretKey key;
    private final AppProperties props;

    public JwtService(AppProperties props) {
        this.props = props;
        this.key = Keys.hmacShaKeyFor(props.getJwt().getSecret().getBytes(StandardCharsets.UTF_8));
    }

    public String issueAccessToken(CommitteeUser user) {
        Instant now = Instant.now();
        return Jwts.builder()
                .subject(user.getId().toString())
                .claim("role", user.getRole().name())
                .claim("tv", user.getTokenVersion())
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(props.getJwt().getAccessTtl())))
                .signWith(key)
                .compact();
    }

    /** Parses and verifies an access token; throws 401 on any problem. */
    public Claims parseAccessToken(String token) {
        try {
            return Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();
        } catch (JwtException | IllegalArgumentException e) {
            throw ApiException.unauthorized("invalid_token", "Invalid or expired token");
        }
    }

    public String issueResetToken(UUID userId) {
        Instant now = Instant.now();
        return Jwts.builder()
                .subject(userId.toString())
                .claim("typ", RESET_TYPE)
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(props.getResetToken().getTtl())))
                .signWith(key)
                .compact();
    }

    /** Validates a reset token and returns the user id; throws 401 otherwise. */
    public UUID parseResetToken(String token) {
        try {
            Claims c = Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();
            if (!RESET_TYPE.equals(c.get("typ"))) {
                throw ApiException.unauthorized("invalid_reset_token", "Not a valid reset token");
            }
            return UUID.fromString(c.getSubject());
        } catch (JwtException | IllegalArgumentException e) {
            throw ApiException.unauthorized("invalid_reset_token", "Invalid or expired reset token");
        }
    }

    public long accessTtlSeconds() {
        return props.getJwt().getAccessTtl().toSeconds();
    }
}
