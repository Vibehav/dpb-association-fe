package in.dpbmandal.api.auth.service;

/**
 * Delivers a one-time code to a phone number. The real SMS provider (MSG91 /
 * Fast2SMS, pending DLT registration) will be a second implementation swapped in
 * without touching the auth flow.
 */
public interface OtpSender {

    void send(String phone, String code);
}
