package in.dpbmandal.api.committee.controller;

import in.dpbmandal.api.committee.dto.AddCommitteeRequest;
import in.dpbmandal.api.committee.dto.ChangeRoleRequest;
import in.dpbmandal.api.committee.dto.CommitteeMemberResponse;
import in.dpbmandal.api.committee.service.CommitteeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/committee")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class CommitteeController {

    private final CommitteeService committeeService;

    @GetMapping
    public List<CommitteeMemberResponse> list() {
        return committeeService.list();
    }

    @GetMapping("/{id}")
    public CommitteeMemberResponse get(@PathVariable UUID id) {
        return committeeService.get(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CommitteeMemberResponse add(@Valid @RequestBody AddCommitteeRequest req) {
        return committeeService.add(req);
    }

    @PatchMapping("/{id}")
    public CommitteeMemberResponse changeRole(@PathVariable UUID id, @Valid @RequestBody ChangeRoleRequest req) {
        return committeeService.changeRole(id, req.role());
    }

    @PostMapping("/{id}/reset-pin")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void resetPin(@PathVariable UUID id) {
        committeeService.resetPin(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remove(@PathVariable UUID id) {
        committeeService.remove(id);
    }
}
