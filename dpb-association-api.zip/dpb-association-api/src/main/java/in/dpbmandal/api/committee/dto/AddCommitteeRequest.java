package in.dpbmandal.api.committee.dto;

import in.dpbmandal.api.committee.enums.Role;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public record AddCommitteeRequest(
        @NotBlank String name,
        @NotBlank @Pattern(regexp = "\\d{10}", message = "must be 10 digits") String phone,
        @NotNull Role role) {
}
