package in.dpbmandal.api.committee.dto;

import in.dpbmandal.api.committee.enums.Role;
import jakarta.validation.constraints.NotNull;

public record ChangeRoleRequest(@NotNull Role role) {
}
