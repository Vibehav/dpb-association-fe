package in.dpbmandal.api.committee.dto;

import in.dpbmandal.api.committee.enums.Role;

import java.time.Instant;
import java.util.UUID;

/** {@code removedAt} is null for active members; set (with active=false) once removed. */
public record CommitteeMemberResponse(
        UUID id,
        String name,
        String phone,
        Role role,
        boolean active,
        boolean pinSet,
        Instant removedAt) {
}
