package in.dpbmandal.api.committee.enums;

public enum Role {
    ADMIN,
    COLLECTOR,
    VIEWER
}
