package in.dpbmandal.api.committee.repo;

import in.dpbmandal.api.committee.entity.CommitteeUser;
import in.dpbmandal.api.committee.enums.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CommitteeUserRepository extends JpaRepository<CommitteeUser, UUID> {

    Optional<CommitteeUser> findByPhoneAndDeletedAtIsNull(String phone);

    /** Active member (not removed) — used for role change / reset / remove. */
    Optional<CommitteeUser> findByIdAndDeletedAtIsNull(UUID id);

    boolean existsByPhoneAndDeletedAtIsNull(String phone);

    /** How many admins can currently sign in (for the "keep >=1 admin" guard). */
    long countByRoleAndActiveTrueAndDeletedAtIsNull(Role role);

    /** Everyone, active first then removed, for the committee screen. */
    List<CommitteeUser> findAllByOrderByActiveDescCreatedAtAsc();
}
