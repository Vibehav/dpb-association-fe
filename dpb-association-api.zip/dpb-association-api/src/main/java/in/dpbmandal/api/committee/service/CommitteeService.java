package in.dpbmandal.api.committee.service;

import in.dpbmandal.api.auth.repo.RefreshTokenRepository;
import in.dpbmandal.api.committee.dto.AddCommitteeRequest;
import in.dpbmandal.api.committee.dto.CommitteeMemberResponse;
import in.dpbmandal.api.committee.entity.CommitteeUser;
import in.dpbmandal.api.committee.enums.Role;
import in.dpbmandal.api.committee.repo.CommitteeUserRepository;
import in.dpbmandal.api.common.exception.ApiException;
import in.dpbmandal.api.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CommitteeService {

    private final CommitteeUserRepository committeeRepo;
    private final RefreshTokenRepository refreshTokenRepo;

    // ---- read ---------------------------------------------------------------

    @Transactional(readOnly = true)
    public List<CommitteeMemberResponse> list() {
        return committeeRepo.findAllByOrderByActiveDescCreatedAtAsc().stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public CommitteeMemberResponse get(UUID id) {
        return committeeRepo.findById(id).map(this::toResponse)
                .orElseThrow(() -> ApiException.notFound("committee_not_found", "Committee member not found"));
    }

    // ---- add ----------------------------------------------------------------

    @Transactional
    public CommitteeMemberResponse add(AddCommitteeRequest req) {
        if (committeeRepo.existsByPhoneAndDeletedAtIsNull(req.phone())) {
            throw ApiException.conflict("duplicate_phone", "This number is already on the committee");
        }
        CommitteeUser user = new CommitteeUser();
        user.setName(req.name().trim());
        user.setPhone(req.phone());
        user.setRole(req.role());
        user.setPinSet(false);   // sets their own PIN via first-login OTP
        user.setActive(true);
        return toResponse(committeeRepo.save(user));
    }

    // ---- change role --------------------------------------------------------

    @Transactional
    public CommitteeMemberResponse changeRole(UUID id, Role role) {
        ensureNotSelf(id);
        CommitteeUser user = activeById(id);
        // Demoting the last admin would leave the association with no admin.
        if (user.getRole() == Role.ADMIN && role != Role.ADMIN && isOnlyAdmin(user)) {
            throw ApiException.badRequest("last_admin", "The association must keep at least one admin");
        }
        user.setRole(role);   // takes effect on the user's next request (role re-derived from DB)
        return toResponse(user);
    }

    // ---- reset pin ----------------------------------------------------------

    @Transactional
    public void resetPin(UUID id) {
        CommitteeUser user = activeById(id);
        user.setPinHash(null);
        user.setPinSet(false);
        user.setFailedPinAttempts(0);
        user.setLockedUntil(null);
        invalidateSessions(user);   // they must set a new PIN before signing in again
    }

    // ---- remove -------------------------------------------------------------

    @Transactional
    public void remove(UUID id) {
        ensureNotSelf(id);
        CommitteeUser user = activeById(id);
        if (user.getRole() == Role.ADMIN && isOnlyAdmin(user)) {
            throw ApiException.badRequest("last_admin", "The association must keep at least one admin");
        }
        user.setActive(false);
        user.setDeletedAt(Instant.now());   // frees the phone; row stays for the audit trail
        invalidateSessions(user);
    }

    // ---- helpers ------------------------------------------------------------

    private CommitteeUser activeById(UUID id) {
        return committeeRepo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> ApiException.notFound("committee_not_found", "Committee member not found"));
    }

    private void ensureNotSelf(UUID id) {
        if (id.equals(SecurityUtils.currentUserId())) {
            throw ApiException.badRequest("self_action", "You cannot change or remove yourself — another admin must");
        }
    }

    private boolean isOnlyAdmin(CommitteeUser user) {
        return user.getRole() == Role.ADMIN
                && committeeRepo.countByRoleAndActiveTrueAndDeletedAtIsNull(Role.ADMIN) <= 1;
    }

    /** Bump token_version (kills access tokens) and revoke refresh tokens. */
    private void invalidateSessions(CommitteeUser user) {
        user.setTokenVersion(user.getTokenVersion() + 1);
        refreshTokenRepo.revokeAllForUser(user.getId(), Instant.now());
    }

    private CommitteeMemberResponse toResponse(CommitteeUser u) {
        return new CommitteeMemberResponse(u.getId(), u.getName(), u.getPhone(), u.getRole(),
                u.isActive(), u.isPinSet(), u.getDeletedAt());
    }
}
