package in.dpbmandal.api.common;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;

/**
 * Strongly-typed {@code app.*} configuration (auth knobs). Registered via
 * {@code @EnableConfigurationProperties} in the security config.
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "app")
public class AppProperties {

    private final Jwt jwt = new Jwt();
    private final Refresh refresh = new Refresh();
    private final Otp otp = new Otp();
    private final ResetToken resetToken = new ResetToken();
    private final Pin pin = new Pin();
    private final S3 s3 = new S3();

    @Getter
    @Setter
    public static class Jwt {
        private String secret;
        private Duration accessTtl;
    }

    @Getter
    @Setter
    public static class Refresh {
        private Duration ttl;
    }

    @Getter
    @Setter
    public static class Otp {
        private Duration ttl;
        private int length;
        private Duration resendThrottle;
        /** Max verify attempts against a single code before it is dead. */
        private int maxVerifyAttempts = 5;
    }

    @Getter
    @Setter
    public static class ResetToken {
        private Duration ttl;
    }

    @Getter
    @Setter
    public static class Pin {
        private int maxAttempts;
        private Duration lockDuration;
    }

    @Getter
    @Setter
    public static class S3 {
        private String endpoint;
        private String region;
        private String accessKey;
        private String secretKey;
        private String bucket;
        private boolean pathStyle = true;
        private Duration uploadUrlTtl;
        private Duration downloadUrlTtl;
    }
}
