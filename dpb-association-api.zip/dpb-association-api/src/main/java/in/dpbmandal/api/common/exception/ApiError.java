package in.dpbmandal.api.common.exception;

/** Uniform error body returned to clients. */
public record ApiError(String code, String message) {
}
