package in.dpbmandal.api.link.enums;

public enum LinkRole {
    OWNER,
    RENTER,
    STAFF
}
