package in.dpbmandal.api.link.enums;

public enum ShopLinkAuditAction {
    ADDED,
    REMOVED
}
