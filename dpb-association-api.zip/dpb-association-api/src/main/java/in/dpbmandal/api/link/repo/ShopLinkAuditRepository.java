package in.dpbmandal.api.link.repo;

import in.dpbmandal.api.link.entity.ShopLinkAudit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ShopLinkAuditRepository extends JpaRepository<ShopLinkAudit, UUID> {
}
