package in.dpbmandal.api.link.repo;

import in.dpbmandal.api.link.entity.ShopLink;
import in.dpbmandal.api.link.enums.LinkRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ShopLinkRepository extends JpaRepository<ShopLink, UUID> {

    List<ShopLink> findByShopIdAndDeletedAtIsNull(UUID shopId);

    List<ShopLink> findByPersonIdAndDeletedAtIsNull(UUID personId);

    List<ShopLink> findByShopIdInAndDeletedAtIsNull(Collection<UUID> shopIds);

    Optional<ShopLink> findByShopIdAndRoleAndDeletedAtIsNull(UUID shopId, LinkRole role);

    Optional<ShopLink> findByShopIdAndPersonIdAndDeletedAtIsNull(UUID shopId, UUID personId);

    Optional<ShopLink> findByIdAndDeletedAtIsNull(UUID id);
}
