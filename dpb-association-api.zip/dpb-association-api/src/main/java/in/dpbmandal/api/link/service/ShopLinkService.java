package in.dpbmandal.api.link.service;

import in.dpbmandal.api.common.exception.ApiException;
import in.dpbmandal.api.link.entity.ShopLink;
import in.dpbmandal.api.link.entity.ShopLinkAudit;
import in.dpbmandal.api.link.enums.LinkRole;
import in.dpbmandal.api.link.enums.ShopLinkAuditAction;
import in.dpbmandal.api.link.repo.ShopLinkAuditRepository;
import in.dpbmandal.api.link.repo.ShopLinkRepository;
import in.dpbmandal.api.person.entity.Person;
import in.dpbmandal.api.person.service.PersonCreationService;
import in.dpbmandal.api.security.SecurityUtils;
import in.dpbmandal.api.shop.dto.AddLinkRequest;
import in.dpbmandal.api.shop.entity.Shop;
import in.dpbmandal.api.shop.repo.ShopRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ShopLinkService {

    private final ShopLinkRepository linkRepo;
    private final ShopLinkAuditRepository auditRepo;
    private final ShopRepository shopRepo;
    private final PersonCreationService personService;

    /** Internal: create a link of any role (used for OWNER by register/transfer). */
    public ShopLink createLink(UUID shopId, UUID personId, LinkRole role) {
        UUID actor = SecurityUtils.currentUserId();
        ShopLink link = new ShopLink();
        link.setShopId(shopId);
        link.setPersonId(personId);
        link.setRole(role);
        link.setCreatedBy(actor);
        ShopLink saved = linkRepo.save(link);
        audit(saved, ShopLinkAuditAction.ADDED, actor);
        return saved;
    }

    /** Public add-link path: RENTER or STAFF only, existing or new person. */
    @Transactional
    public void addLink(UUID shopId, AddLinkRequest req) {
        if (req.role() == LinkRole.OWNER) {
            throw ApiException.badRequest("owner_not_addable",
                    "The licence holder is set through registration or Transfer, not here");
        }
        Shop shop = shopRepo.findByIdAndDeletedAtIsNull(shopId)
                .orElseThrow(() -> ApiException.notFound("shop_not_found", "Shop not found"));

        Person person = personService.resolve(req.existingPersonId(), req.newPerson());

        if (linkRepo.findByShopIdAndPersonIdAndDeletedAtIsNull(shop.getId(), person.getId()).isPresent()) {
            throw ApiException.conflict("already_linked", "This member is already linked to this shop");
        }
        if (req.role() == LinkRole.RENTER
                && linkRepo.findByShopIdAndRoleAndDeletedAtIsNull(shop.getId(), LinkRole.RENTER).isPresent()) {
            throw ApiException.conflict("renter_exists", "This shop already has a renter");
        }
        createLink(shop.getId(), person.getId(), req.role());
    }

    @Transactional
    public void removeLink(UUID linkId) {
        ShopLink link = linkRepo.findByIdAndDeletedAtIsNull(linkId)
                .orElseThrow(() -> ApiException.notFound("link_not_found", "Link not found"));
        if (link.getRole() == LinkRole.OWNER) {
            throw ApiException.badRequest("owner_not_removable",
                    "The licence holder can only be changed through Transfer");
        }
        softRemove(link);
    }

    /** Internal: soft-remove a link and audit it (used by remove/transfer/shop-delete). */
    public void softRemove(ShopLink link) {
        UUID actor = SecurityUtils.currentUserId();
        Instant now = Instant.now();
        link.setDeletedAt(now);
        link.setRemovedBy(actor);
        link.setRemovedAt(now);
        linkRepo.save(link);
        audit(link, ShopLinkAuditAction.REMOVED, actor);
    }

    private void audit(ShopLink link, ShopLinkAuditAction action, UUID actor) {
        ShopLinkAudit a = new ShopLinkAudit();
        a.setLinkId(link.getId());
        a.setShopId(link.getShopId());
        a.setPersonId(link.getPersonId());
        a.setRole(link.getRole());
        a.setAction(action);
        a.setActorId(actor);
        a.setOccurredAt(Instant.now());
        auditRepo.save(a);
    }
}
