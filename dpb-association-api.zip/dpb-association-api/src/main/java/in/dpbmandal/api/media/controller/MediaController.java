package in.dpbmandal.api.media.controller;

import in.dpbmandal.api.media.dto.UploadUrlRequest;
import in.dpbmandal.api.media.dto.UploadUrlResponse;
import in.dpbmandal.api.media.service.MediaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/media")
@RequiredArgsConstructor
public class MediaController {

    private final MediaService mediaService;

    @PostMapping("/upload-url")
    @PreAuthorize("hasAnyRole('ADMIN','COLLECTOR')")
    public UploadUrlResponse uploadUrl(@Valid @RequestBody UploadUrlRequest req) {
        return mediaService.presignUpload(req.type());
    }
}
