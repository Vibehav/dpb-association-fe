package in.dpbmandal.api.media.dto;

/** A short-lived signed GET url for viewing/downloading an object. */
public record SignedUrlResponse(String url, long expiresInSeconds) {
}
