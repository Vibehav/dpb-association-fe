package in.dpbmandal.api.media.dto;

import in.dpbmandal.api.media.enums.MediaType;
import jakarta.validation.constraints.NotNull;

public record UploadUrlRequest(@NotNull MediaType type) {
}
