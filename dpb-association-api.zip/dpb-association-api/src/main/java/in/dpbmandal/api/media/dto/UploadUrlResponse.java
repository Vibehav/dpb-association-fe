package in.dpbmandal.api.media.dto;

/** {@code key} is stored on the entity; the client PUTs the bytes to {@code uploadUrl}. */
public record UploadUrlResponse(String key, String uploadUrl, long expiresInSeconds) {
}
