package in.dpbmandal.api.media.enums;

/** Kind of upload; determines the S3 key namespace. */
public enum MediaType {
    PHOTO("photos/"),
    AADHAAR_FRONT("aadhaar/"),
    AADHAAR_BACK("aadhaar/");

    private final String prefix;

    MediaType(String prefix) {
        this.prefix = prefix;
    }

    public String prefix() {
        return prefix;
    }
}
