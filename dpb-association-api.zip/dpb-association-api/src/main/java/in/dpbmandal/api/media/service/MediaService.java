package in.dpbmandal.api.media.service;

import in.dpbmandal.api.common.AppProperties;
import in.dpbmandal.api.media.dto.SignedUrlResponse;
import in.dpbmandal.api.media.dto.UploadUrlResponse;
import in.dpbmandal.api.media.enums.MediaType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;

import java.time.Duration;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class MediaService {

    private final S3Presigner presigner;
    private final AppProperties props;

    /** Presigned PUT for a fresh object; the returned key is stored on the entity. */
    public UploadUrlResponse presignUpload(MediaType type) {
        String key = type.prefix() + UUID.randomUUID();
        Duration ttl = props.getS3().getUploadUrlTtl();
        PutObjectRequest put = PutObjectRequest.builder()
                .bucket(bucket()).key(key).build();
        var presigned = presigner.presignPutObject(b -> b.signatureDuration(ttl).putObjectRequest(put));
        return new UploadUrlResponse(key, presigned.url().toString(), ttl.toSeconds());
    }

    /** Short-lived presigned GET for viewing an object. */
    public SignedUrlResponse presignGet(String key) {
        Duration ttl = props.getS3().getDownloadUrlTtl();
        GetObjectRequest get = GetObjectRequest.builder()
                .bucket(bucket()).key(key).build();
        var presigned = presigner.presignGetObject(b -> b.signatureDuration(ttl).getObjectRequest(get));
        return new SignedUrlResponse(presigned.url().toString(), ttl.toSeconds());
    }

    private String bucket() {
        return props.getS3().getBucket();
    }
}
