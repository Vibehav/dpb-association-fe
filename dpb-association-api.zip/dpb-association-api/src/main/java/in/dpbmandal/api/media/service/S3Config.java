package in.dpbmandal.api.media.service;

import in.dpbmandal.api.common.AppProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3Configuration;
import software.amazon.awssdk.services.s3.model.CreateBucketRequest;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;

import java.net.URI;

/** S3/MinIO clients, plus a startup runner that creates the bucket if it is missing (dev). */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class S3Config {

    private final AppProperties props;

    private StaticCredentialsProvider credentials() {
        AppProperties.S3 s3 = props.getS3();
        return StaticCredentialsProvider.create(
                AwsBasicCredentials.create(s3.getAccessKey(), s3.getSecretKey()));
    }

    @Bean
    public S3Client s3Client() {
        AppProperties.S3 s3 = props.getS3();
        return S3Client.builder()
                .endpointOverride(URI.create(s3.getEndpoint()))
                .region(Region.of(s3.getRegion()))
                .credentialsProvider(credentials())
                .forcePathStyle(s3.isPathStyle())
                .build();
    }

    @Bean
    public S3Presigner s3Presigner() {
        AppProperties.S3 s3 = props.getS3();
        return S3Presigner.builder()
                .endpointOverride(URI.create(s3.getEndpoint()))
                .region(Region.of(s3.getRegion()))
                .credentialsProvider(credentials())
                .serviceConfiguration(S3Configuration.builder()
                        .pathStyleAccessEnabled(s3.isPathStyle())
                        .build())
                .build();
    }

    @Bean
    public ApplicationRunner s3BucketInitializer(S3Client s3) {
        return args -> {
            String bucket = props.getS3().getBucket();
            boolean exists = s3.listBuckets().buckets().stream()
                    .anyMatch(b -> b.name().equals(bucket));
            if (!exists) {
                s3.createBucket(CreateBucketRequest.builder().bucket(bucket).build());
                log.info("Created media bucket '{}'", bucket);
            }
        };
    }
}
