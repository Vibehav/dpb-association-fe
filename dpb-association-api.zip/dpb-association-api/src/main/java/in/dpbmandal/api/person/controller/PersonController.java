package in.dpbmandal.api.person.controller;

import in.dpbmandal.api.common.PagedResponse;
import in.dpbmandal.api.link.enums.LinkRole;
import in.dpbmandal.api.person.dto.AddPersonLinkRequest;
import in.dpbmandal.api.person.dto.CreatePersonRequest;
import in.dpbmandal.api.person.dto.PersonListItemResponse;
import in.dpbmandal.api.person.dto.PersonProfileResponse;
import in.dpbmandal.api.person.dto.UpdatePersonRequest;
import in.dpbmandal.api.person.service.PersonService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/people")
@RequiredArgsConstructor
public class PersonController {

    private final PersonService personService;

    @GetMapping
    public PagedResponse<PersonListItemResponse> list(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) LinkRole role,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return personService.list(query, role, page, size);
    }

    @GetMapping("/{id}")
    public PersonProfileResponse profile(@PathVariable UUID id) {
        return personService.profile(id);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','COLLECTOR')")
    @ResponseStatus(HttpStatus.CREATED)
    public PersonProfileResponse create(@Valid @RequestBody CreatePersonRequest req) {
        return personService.create(req);
    }

    @PatchMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','COLLECTOR')")
    public PersonProfileResponse update(@PathVariable UUID id, @Valid @RequestBody UpdatePersonRequest req) {
        return personService.update(id, req);
    }

    @PostMapping("/{id}/links")
    @PreAuthorize("hasAnyRole('ADMIN','COLLECTOR')")
    public PersonProfileResponse addLink(@PathVariable UUID id, @Valid @RequestBody AddPersonLinkRequest req) {
        return personService.addLink(id, req);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable UUID id) {
        personService.softDelete(id);
    }
}
