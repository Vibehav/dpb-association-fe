package in.dpbmandal.api.person.controller;

import in.dpbmandal.api.audit.enums.AadhaarSide;
import in.dpbmandal.api.media.dto.SignedUrlResponse;
import in.dpbmandal.api.person.dto.AadhaarUpdateRequest;
import in.dpbmandal.api.person.dto.PhotoUpdateRequest;
import in.dpbmandal.api.person.service.PersonMediaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/people/{id}")
@RequiredArgsConstructor
public class PersonMediaController {

    private final PersonMediaService mediaService;

    @GetMapping("/photo")
    public SignedUrlResponse photo(@PathVariable UUID id) {
        return mediaService.photoUrl(id);
    }

    @PutMapping("/photo")
    @PreAuthorize("hasAnyRole('ADMIN','COLLECTOR')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void retakePhoto(@PathVariable UUID id, @Valid @RequestBody PhotoUpdateRequest req) {
        mediaService.retakePhoto(id, req.key());
    }

    @GetMapping("/aadhaar/{side}")
    @PreAuthorize("hasRole('ADMIN')")
    public SignedUrlResponse aadhaar(@PathVariable UUID id, @PathVariable AadhaarSide side) {
        return mediaService.aadhaarUrl(id, side);
    }

    @PutMapping("/aadhaar")
    @PreAuthorize("hasAnyRole('ADMIN','COLLECTOR')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void recaptureAadhaar(@PathVariable UUID id, @Valid @RequestBody AadhaarUpdateRequest req) {
        mediaService.recaptureAadhaar(id, req.side(), req.key());
    }
}
