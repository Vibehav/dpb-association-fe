package in.dpbmandal.api.person.dto;

import in.dpbmandal.api.audit.enums.AadhaarSide;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/** Re-capture: replace one side of the Aadhaar with a freshly uploaded key. */
public record AadhaarUpdateRequest(@NotNull AadhaarSide side, @NotBlank String key) {
}
