package in.dpbmandal.api.person.dto;

import in.dpbmandal.api.link.enums.LinkRole;
import jakarta.validation.constraints.NotNull;

import java.util.UUID;

/** Link an existing member to another shop (RENTER/STAFF). */
public record AddPersonLinkRequest(@NotNull UUID shopId, @NotNull LinkRole role) {
}
