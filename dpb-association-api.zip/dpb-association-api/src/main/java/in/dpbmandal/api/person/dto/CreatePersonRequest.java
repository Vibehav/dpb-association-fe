package in.dpbmandal.api.person.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

/** Standalone "+ Add a member": create the person plus at least one RENTER/STAFF link. */
public record CreatePersonRequest(
        @NotNull @Valid NewPersonRequest person,
        @NotEmpty @Valid List<PersonLinkInput> links) {
}
