package in.dpbmandal.api.person.dto;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/**
 * Payload to create a market person inline (shop registration / add-link / transfer).
 * {@code photoKey} and {@code aadhaarFrontKey} are S3 keys the client obtained by
 * uploading first (media wired in the People slice; placeholders accepted meanwhile).
 */
public record NewPersonRequest(
        @NotBlank String name,
        @NotBlank @Pattern(regexp = "\\d{10}", message = "must be 10 digits") String phone,
        @Pattern(regexp = "\\d{10}", message = "must be 10 digits") String whatsappPhone,
        String address,
        @NotBlank String photoKey,
        @NotBlank String aadhaarFrontKey,
        String aadhaarBackKey,
        @Pattern(regexp = "\\d{4}", message = "must be 4 digits") String aadhaarLast4,
        @AssertTrue(message = "consent is required") boolean consent) {
}
