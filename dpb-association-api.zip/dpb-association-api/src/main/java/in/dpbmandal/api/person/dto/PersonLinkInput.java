package in.dpbmandal.api.person.dto;

import in.dpbmandal.api.link.enums.LinkRole;
import jakarta.validation.constraints.NotNull;

import java.util.UUID;

/** One shop+role to link when creating a member (RENTER/STAFF only — owner via shop reg/transfer). */
public record PersonLinkInput(@NotNull UUID shopId, @NotNull LinkRole role) {
}
