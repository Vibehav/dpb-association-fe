package in.dpbmandal.api.person.dto;

import java.util.List;
import java.util.UUID;

public record PersonListItemResponse(
        UUID id,
        String name,
        String phone,
        List<PersonShopLinkResponse> shops) {
}
