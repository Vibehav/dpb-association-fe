package in.dpbmandal.api.person.dto;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
 * Aadhaar image itself is fetched separately (admin-only, logged). Here we expose only
 * the non-sensitive metadata: last-4, consent, and who captured the record and when.
 */
public record PersonProfileResponse(
        UUID id,
        String name,
        String phone,
        String whatsappPhone,
        String address,
        String aadhaarLast4,
        boolean consent,
        String addedByName,
        Instant addedOn,
        String photoUrl,
        List<PersonShopLinkResponse> shops) {
}
