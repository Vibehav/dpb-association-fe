package in.dpbmandal.api.person.dto;

import in.dpbmandal.api.link.enums.LinkRole;

import java.util.UUID;

public record PersonShopLinkResponse(
        UUID linkId,
        UUID shopId,
        String shopNumber,
        String businessName,
        LinkRole role) {
}
