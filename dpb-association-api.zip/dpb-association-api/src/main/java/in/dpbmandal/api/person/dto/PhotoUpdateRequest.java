package in.dpbmandal.api.person.dto;

import jakarta.validation.constraints.NotBlank;

/** Retake: replace the member photo with a freshly uploaded key. */
public record PhotoUpdateRequest(@NotBlank String key) {
}
