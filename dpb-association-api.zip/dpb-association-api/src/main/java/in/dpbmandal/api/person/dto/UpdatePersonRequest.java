package in.dpbmandal.api.person.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record UpdatePersonRequest(
        @NotBlank String name,
        @NotBlank @Pattern(regexp = "\\d{10}", message = "must be 10 digits") String phone,
        @Pattern(regexp = "\\d{10}", message = "must be 10 digits") String whatsappPhone,
        String address) {
}
