package in.dpbmandal.api.person.entity;

import in.dpbmandal.api.common.AuditableEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

@Getter
@Setter
@Entity
@Table(name = "person")
public class Person extends AuditableEntity {

    @Column(nullable = false, length = 150)
    private String name;

    @Column(nullable = false, length = 10)
    private String phone;

    @Column(name = "whatsapp_phone", length = 10)
    private String whatsappPhone;

    @Column(columnDefinition = "text")
    private String address;

    @Column(name = "photo_key", nullable = false, length = 512)
    private String photoKey;

    @Column(name = "aadhaar_front_key", nullable = false, length = 512)
    private String aadhaarFrontKey;

    @Column(name = "aadhaar_back_key", length = 512)
    private String aadhaarBackKey;

    @Column(name = "aadhaar_last4", length = 4)
    private String aadhaarLast4;

    @Column(nullable = false)
    private boolean consent = false;

    @Column(name = "consent_at")
    private Instant consentAt;

    @Column(name = "deleted_at")
    private Instant deletedAt;
}
