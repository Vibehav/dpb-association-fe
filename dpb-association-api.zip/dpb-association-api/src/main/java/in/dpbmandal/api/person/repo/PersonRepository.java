package in.dpbmandal.api.person.repo;

import in.dpbmandal.api.person.entity.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PersonRepository extends JpaRepository<Person, UUID> {

    Optional<Person> findByPhoneAndDeletedAtIsNull(String phone);

    Optional<Person> findByIdAndDeletedAtIsNull(UUID id);

    boolean existsByPhoneAndDeletedAtIsNull(String phone);

    /**
     * Page of active person ids matching the (already lowercased) search pattern and role.
     * Pass null for {@code q}/{@code role} to skip that filter. Search covers name, phone,
     * and any linked shop's number; role filters to people holding that link role.
     */
    @Query(value = """
            select p.id from person p
            where p.deleted_at is null
              and (:role is null or exists (select 1 from shop_link l
                                            where l.person_id = p.id and l.deleted_at is null and l.role = :role))
              and (:q is null
                   or lower(p.name) like :q
                   or p.phone like :q
                   or exists (select 1 from shop_link l
                                join shop s on s.id = l.shop_id
                              where l.person_id = p.id and l.deleted_at is null and s.deleted_at is null
                                and lower(s.shop_number) like :q))
            order by p.created_at desc
            limit :size offset :offset
            """, nativeQuery = true)
    List<UUID> searchPersonIds(@Param("q") String q, @Param("role") String role,
                               @Param("size") int size, @Param("offset") int offset);

    @Query(value = """
            select count(*) from person p
            where p.deleted_at is null
              and (:role is null or exists (select 1 from shop_link l
                                            where l.person_id = p.id and l.deleted_at is null and l.role = :role))
              and (:q is null
                   or lower(p.name) like :q
                   or p.phone like :q
                   or exists (select 1 from shop_link l
                                join shop s on s.id = l.shop_id
                              where l.person_id = p.id and l.deleted_at is null and s.deleted_at is null
                                and lower(s.shop_number) like :q))
            """, nativeQuery = true)
    long countSearch(@Param("q") String q, @Param("role") String role);
}
