package in.dpbmandal.api.person.service;

import in.dpbmandal.api.common.exception.ApiException;
import in.dpbmandal.api.person.dto.NewPersonRequest;
import in.dpbmandal.api.person.entity.Person;
import in.dpbmandal.api.person.repo.PersonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

/**
 * Shared person creation used by the registration flows (shop register / add-link /
 * transfer). Deliberately has no standalone create endpoint — every path creates the
 * person together with a shop link in the caller's transaction, so a person is never
 * momentarily shopless.
 */
@Service
@RequiredArgsConstructor
public class PersonCreationService {

    private final PersonRepository personRepo;

    /** Resolves an existing active person by id, or creates a new one — exactly one input. */
    public Person resolve(UUID existingPersonId, NewPersonRequest newPerson) {
        boolean hasExisting = existingPersonId != null;
        boolean hasNew = newPerson != null;
        if (hasExisting == hasNew) {
            throw ApiException.badRequest("person_input",
                    "Provide exactly one of an existing person or a new person");
        }
        if (hasExisting) {
            return personRepo.findByIdAndDeletedAtIsNull(existingPersonId)
                    .orElseThrow(() -> ApiException.notFound("person_not_found", "Member not found"));
        }
        return create(newPerson);
    }

    public Person create(NewPersonRequest req) {
        if (!req.consent()) {
            throw ApiException.badRequest("consent_required", "Consent is required");
        }
        if (personRepo.existsByPhoneAndDeletedAtIsNull(req.phone())) {
            throw ApiException.conflict("duplicate_phone", "A member with this phone number already exists");
        }
        Person p = new Person();
        p.setName(req.name().trim());
        p.setPhone(req.phone());
        p.setWhatsappPhone(hasText(req.whatsappPhone()) ? req.whatsappPhone() : req.phone());
        p.setAddress(req.address());
        p.setPhotoKey(req.photoKey());
        p.setAadhaarFrontKey(req.aadhaarFrontKey());
        p.setAadhaarBackKey(req.aadhaarBackKey());
        p.setAadhaarLast4(req.aadhaarLast4());
        p.setConsent(true);
        p.setConsentAt(Instant.now());
        return personRepo.save(p);
    }

    private boolean hasText(String s) {
        return s != null && !s.isBlank();
    }
}
