package in.dpbmandal.api.person.service;

import in.dpbmandal.api.audit.entity.AadhaarAccessLog;
import in.dpbmandal.api.audit.enums.AadhaarAction;
import in.dpbmandal.api.audit.enums.AadhaarSide;
import in.dpbmandal.api.audit.repo.AadhaarAccessLogRepository;
import in.dpbmandal.api.common.exception.ApiException;
import in.dpbmandal.api.media.dto.SignedUrlResponse;
import in.dpbmandal.api.media.service.MediaService;
import in.dpbmandal.api.person.entity.Person;
import in.dpbmandal.api.person.repo.PersonRepository;
import in.dpbmandal.api.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PersonMediaService {

    private final PersonRepository personRepo;
    private final MediaService mediaService;
    private final AadhaarAccessLogRepository aadhaarLogRepo;

    // ---- photo (viewable by all) -------------------------------------------

    @Transactional(readOnly = true)
    public SignedUrlResponse photoUrl(UUID personId) {
        Person person = activePerson(personId);
        return mediaService.presignGet(person.getPhotoKey());
    }

    @Transactional
    public void retakePhoto(UUID personId, String key) {
        Person person = activePerson(personId);
        person.setPhotoKey(key);
    }

    // ---- aadhaar (admin-only view; every access logged) ---------------------

    @Transactional
    public SignedUrlResponse aadhaarUrl(UUID personId, AadhaarSide side) {
        Person person = activePerson(personId);
        String key = side == AadhaarSide.FRONT ? person.getAadhaarFrontKey() : person.getAadhaarBackKey();
        if (key == null) {
            throw ApiException.notFound("aadhaar_missing", "No Aadhaar " + side.name().toLowerCase() + " on file");
        }
        log(person.getId(), AadhaarAction.VIEW, side);
        return mediaService.presignGet(key);
    }

    @Transactional
    public void recaptureAadhaar(UUID personId, AadhaarSide side, String key) {
        Person person = activePerson(personId);
        if (side == AadhaarSide.FRONT) {
            person.setAadhaarFrontKey(key);
        } else {
            person.setAadhaarBackKey(key);
        }
        log(person.getId(), AadhaarAction.RECAPTURE, side);
    }

    // ---- helpers ------------------------------------------------------------

    private Person activePerson(UUID personId) {
        return personRepo.findByIdAndDeletedAtIsNull(personId)
                .orElseThrow(() -> ApiException.notFound("person_not_found", "Member not found"));
    }

    private void log(UUID personId, AadhaarAction action, AadhaarSide side) {
        AadhaarAccessLog entry = new AadhaarAccessLog();
        entry.setPersonId(personId);
        entry.setCommitteeUserId(SecurityUtils.currentUserId());
        entry.setAction(action);
        entry.setSide(side);
        entry.setAccessedAt(Instant.now());
        aadhaarLogRepo.save(entry);
    }
}
