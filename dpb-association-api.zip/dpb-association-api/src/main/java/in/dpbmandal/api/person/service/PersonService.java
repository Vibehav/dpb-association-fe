package in.dpbmandal.api.person.service;

import in.dpbmandal.api.committee.entity.CommitteeUser;
import in.dpbmandal.api.committee.repo.CommitteeUserRepository;
import in.dpbmandal.api.common.PagedResponse;
import in.dpbmandal.api.common.exception.ApiException;
import in.dpbmandal.api.link.entity.ShopLink;
import in.dpbmandal.api.link.enums.LinkRole;
import in.dpbmandal.api.link.repo.ShopLinkRepository;
import in.dpbmandal.api.link.service.ShopLinkService;
import in.dpbmandal.api.media.service.MediaService;
import in.dpbmandal.api.person.dto.AddPersonLinkRequest;
import in.dpbmandal.api.person.dto.CreatePersonRequest;
import in.dpbmandal.api.person.dto.PersonListItemResponse;
import in.dpbmandal.api.person.dto.PersonProfileResponse;
import in.dpbmandal.api.person.dto.PersonShopLinkResponse;
import in.dpbmandal.api.person.dto.UpdatePersonRequest;
import in.dpbmandal.api.person.entity.Person;
import in.dpbmandal.api.person.repo.PersonRepository;
import in.dpbmandal.api.shop.dto.AddLinkRequest;
import in.dpbmandal.api.shop.entity.Shop;
import in.dpbmandal.api.shop.repo.ShopRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PersonService {

    private static final int MAX_PAGE_SIZE = 100;

    private final PersonRepository personRepo;
    private final ShopLinkRepository linkRepo;
    private final ShopRepository shopRepo;
    private final CommitteeUserRepository committeeRepo;
    private final PersonCreationService personCreationService;
    private final ShopLinkService linkService;
    private final MediaService mediaService;

    // ---- create standalone --------------------------------------------------

    @Transactional
    public PersonProfileResponse create(CreatePersonRequest req) {
        Person person = personCreationService.create(req.person());
        // Reuse addLink for each requested link: validates shop existence, uniqueness,
        // one-renter-per-shop, and rejects OWNER (owner only via shop reg/transfer).
        req.links().forEach(link ->
                linkService.addLink(link.shopId(), new AddLinkRequest(link.role(), person.getId(), null)));
        return profile(person.getId());
    }

    // ---- read ---------------------------------------------------------------

    @Transactional(readOnly = true)
    public PagedResponse<PersonListItemResponse> list(String query, LinkRole role, int page, int size) {
        int safeSize = Math.min(Math.max(size, 1), MAX_PAGE_SIZE);
        int safePage = Math.max(page, 0);
        String q = (query == null || query.isBlank()) ? null : "%" + query.trim().toLowerCase() + "%";
        String roleParam = role == null ? null : role.name();

        long total = personRepo.countSearch(q, roleParam);
        List<UUID> ids = personRepo.searchPersonIds(q, roleParam, safeSize, safePage * safeSize);
        if (ids.isEmpty()) {
            return PagedResponse.of(List.of(), safePage, safeSize, total);
        }

        Map<UUID, Person> personsById = personRepo.findAllById(ids).stream()
                .collect(Collectors.toMap(Person::getId, Function.identity()));
        Map<UUID, List<PersonShopLinkResponse>> shopsByPerson = shopLinksForPeople(ids);

        List<PersonListItemResponse> items = ids.stream()
                .map(personsById::get)
                .map(p -> new PersonListItemResponse(p.getId(), p.getName(), p.getPhone(),
                        shopsByPerson.getOrDefault(p.getId(), List.of())))
                .toList();
        return PagedResponse.of(items, safePage, safeSize, total);
    }

    @Transactional(readOnly = true)
    public PersonProfileResponse profile(UUID personId) {
        Person person = activePerson(personId);
        List<PersonShopLinkResponse> shops = shopLinksForPeople(List.of(personId))
                .getOrDefault(personId, List.of());
        String addedByName = person.getCreatedBy() == null ? null
                : committeeRepo.findById(person.getCreatedBy()).map(CommitteeUser::getName).orElse(null);
        String photoUrl = mediaService.presignGet(person.getPhotoKey()).url();

        return new PersonProfileResponse(person.getId(), person.getName(), person.getPhone(),
                person.getWhatsappPhone(), person.getAddress(), person.getAadhaarLast4(), person.isConsent(),
                addedByName, person.getCreatedAt(), photoUrl, shops);
    }

    // ---- update / link / delete --------------------------------------------

    @Transactional
    public PersonProfileResponse update(UUID personId, UpdatePersonRequest req) {
        Person person = activePerson(personId);
        if (!req.phone().equals(person.getPhone())
                && personRepo.existsByPhoneAndDeletedAtIsNull(req.phone())) {
            throw ApiException.conflict("duplicate_phone", "A member with this phone number already exists");
        }
        person.setName(req.name().trim());
        person.setPhone(req.phone());
        person.setWhatsappPhone((req.whatsappPhone() == null || req.whatsappPhone().isBlank())
                ? req.phone() : req.whatsappPhone());
        person.setAddress(req.address());
        return profile(person.getId());
    }

    @Transactional
    public PersonProfileResponse addLink(UUID personId, AddPersonLinkRequest req) {
        activePerson(personId);
        linkService.addLink(req.shopId(), new AddLinkRequest(req.role(), personId, null));
        return profile(personId);
    }

    @Transactional
    public void softDelete(UUID personId) {
        Person person = activePerson(personId);
        person.setDeletedAt(java.time.Instant.now());
        for (ShopLink link : linkRepo.findByPersonIdAndDeletedAtIsNull(personId)) {
            linkService.softRemove(link);
        }
    }

    // ---- helpers ------------------------------------------------------------

    private Person activePerson(UUID personId) {
        return personRepo.findByIdAndDeletedAtIsNull(personId)
                .orElseThrow(() -> ApiException.notFound("person_not_found", "Member not found"));
    }

    /** Active links for the given people, resolved to shop number/business, grouped by person. */
    private Map<UUID, List<PersonShopLinkResponse>> shopLinksForPeople(List<UUID> personIds) {
        List<ShopLink> links = personIds.stream()
                .flatMap(pid -> linkRepo.findByPersonIdAndDeletedAtIsNull(pid).stream())
                .toList();
        Map<UUID, Shop> shopsById = shopRepo.findAllById(links.stream().map(ShopLink::getShopId).toList())
                .stream().collect(Collectors.toMap(Shop::getId, Function.identity()));
        return links.stream().collect(Collectors.groupingBy(ShopLink::getPersonId,
                Collectors.mapping(l -> {
                    Shop s = shopsById.get(l.getShopId());
                    return new PersonShopLinkResponse(l.getId(), l.getShopId(),
                            s != null ? s.getShopNumber() : null,
                            s != null ? s.getBusinessName() : null,
                            l.getRole());
                }, Collectors.toList())));
    }
}
