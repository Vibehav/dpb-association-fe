package in.dpbmandal.api.security;

import in.dpbmandal.api.committee.enums.Role;

import java.util.UUID;

/** The authenticated committee user attached to the security context each request. */
public record AuthPrincipal(UUID userId, Role role) {
}
