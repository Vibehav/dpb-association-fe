package in.dpbmandal.api.security;

import in.dpbmandal.api.auth.service.JwtService;
import in.dpbmandal.api.committee.entity.CommitteeUser;
import in.dpbmandal.api.committee.repo.CommitteeUserRepository;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

/**
 * Authenticates a Bearer access token and — crucially — re-derives the user's rights
 * from the DB on every request: the account must still be active, not soft-deleted,
 * and its token_version must match the token. A demotion or removal therefore takes
 * effect on the very next request.
 */
@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final CommitteeUserRepository userRepo;

    public JwtAuthFilter(JwtService jwtService, CommitteeUserRepository userRepo) {
        this.jwtService = jwtService;
        this.userRepo = userRepo;
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain filterChain) throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            authenticate(request, header.substring(7));
        }
        filterChain.doFilter(request, response);
    }

    private void authenticate(HttpServletRequest request, String token) {
        try {
            Claims claims = jwtService.parseAccessToken(token);
            UUID userId = UUID.fromString(claims.getSubject());
            Integer tokenVersion = claims.get("tv", Integer.class);

            CommitteeUser user = userRepo.findById(userId).orElse(null);
            if (user == null || !user.isActive() || user.getDeletedAt() != null
                    || tokenVersion == null || user.getTokenVersion() != tokenVersion) {
                return; // stale/removed/demoted -> leave request unauthenticated
            }

            AuthPrincipal principal = new AuthPrincipal(user.getId(), user.getRole());
            var authentication = new UsernamePasswordAuthenticationToken(
                    principal, null, List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().name())));
            authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
            SecurityContextHolder.getContext().setAuthentication(authentication);
        } catch (Exception e) {
            // any parsing/validation problem -> unauthenticated; protected routes will 401
            SecurityContextHolder.clearContext();
        }
    }
}
