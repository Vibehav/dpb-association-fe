package in.dpbmandal.api.shop.controller;

import in.dpbmandal.api.common.PagedResponse;
import in.dpbmandal.api.link.service.ShopLinkService;
import in.dpbmandal.api.shop.dto.AddLinkRequest;
import in.dpbmandal.api.shop.dto.RegisterShopRequest;
import in.dpbmandal.api.shop.dto.ShopDetailResponse;
import in.dpbmandal.api.shop.dto.ShopListItemResponse;
import in.dpbmandal.api.shop.dto.TransferRequest;
import in.dpbmandal.api.shop.dto.UpdateShopRequest;
import in.dpbmandal.api.shop.service.ShopService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/shops")
@RequiredArgsConstructor
public class ShopController {

    private final ShopService shopService;
    private final ShopLinkService linkService;

    @GetMapping
    public PagedResponse<ShopListItemResponse> list(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String lane,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return shopService.list(query, lane, page, size);
    }

    @GetMapping("/{id}")
    public ShopDetailResponse detail(@PathVariable UUID id) {
        return shopService.detail(id);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','COLLECTOR')")
    @ResponseStatus(HttpStatus.CREATED)
    public ShopDetailResponse register(@Valid @RequestBody RegisterShopRequest req) {
        return shopService.register(req);
    }

    @PatchMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','COLLECTOR')")
    public ShopDetailResponse update(@PathVariable UUID id, @Valid @RequestBody UpdateShopRequest req) {
        return shopService.update(id, req);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable UUID id) {
        shopService.softDelete(id);
    }

    @PostMapping("/{id}/links")
    @PreAuthorize("hasAnyRole('ADMIN','COLLECTOR')")
    public ShopDetailResponse addLink(@PathVariable UUID id, @Valid @RequestBody AddLinkRequest req) {
        linkService.addLink(id, req);
        return shopService.detail(id);
    }

    @PostMapping("/{id}/transfer")
    @PreAuthorize("hasRole('ADMIN')")
    public ShopDetailResponse transfer(@PathVariable UUID id, @Valid @RequestBody TransferRequest req) {
        return shopService.transfer(id, req);
    }
}
