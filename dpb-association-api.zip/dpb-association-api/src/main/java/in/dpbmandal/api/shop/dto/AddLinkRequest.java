package in.dpbmandal.api.shop.dto;

import in.dpbmandal.api.link.enums.LinkRole;
import in.dpbmandal.api.person.dto.NewPersonRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.util.UUID;

/** Add a RENTER or STAFF to a shop (OWNER is rejected — owner is set via register/transfer). */
public record AddLinkRequest(
        @NotNull LinkRole role,
        UUID existingPersonId,
        @Valid NewPersonRequest newPerson) {
}
