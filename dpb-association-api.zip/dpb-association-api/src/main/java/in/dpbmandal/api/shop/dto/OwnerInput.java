package in.dpbmandal.api.shop.dto;

import in.dpbmandal.api.person.dto.NewPersonRequest;
import jakarta.validation.Valid;

import java.util.UUID;

/** Exactly one of the two: link an existing member as owner, or create a new one. */
public record OwnerInput(UUID existingPersonId, @Valid NewPersonRequest newPerson) {
}
