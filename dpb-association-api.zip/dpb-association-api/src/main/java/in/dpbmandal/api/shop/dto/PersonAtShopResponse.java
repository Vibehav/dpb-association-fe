package in.dpbmandal.api.shop.dto;

import in.dpbmandal.api.link.enums.LinkRole;

import java.util.UUID;

/** A person at a shop. {@code linkId} lets the client target DELETE /links/{linkId}. */
public record PersonAtShopResponse(UUID linkId, UUID personId, String name, String phone, LinkRole role) {
}
