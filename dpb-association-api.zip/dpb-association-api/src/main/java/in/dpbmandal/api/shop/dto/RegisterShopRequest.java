package in.dpbmandal.api.shop.dto;

import in.dpbmandal.api.shop.enums.Tenancy;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record RegisterShopRequest(
        @NotBlank String shopNumber,
        @NotBlank String businessName,
        String lane,
        @NotNull Tenancy tenancy,
        @NotNull @Valid OwnerInput owner) {
}
