package in.dpbmandal.api.shop.dto;

import in.dpbmandal.api.shop.enums.Tenancy;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public record ShopDetailResponse(
        UUID id,
        String shopNumber,
        String businessName,
        String lane,
        Tenancy tenancy,
        String formerHolderName,
        LocalDate formerHolderTill,
        List<PersonAtShopResponse> people) {
}
