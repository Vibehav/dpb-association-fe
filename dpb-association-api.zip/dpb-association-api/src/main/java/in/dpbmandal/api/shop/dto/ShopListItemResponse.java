package in.dpbmandal.api.shop.dto;

import in.dpbmandal.api.shop.enums.Tenancy;

import java.util.UUID;

public record ShopListItemResponse(
        UUID id,
        String shopNumber,
        String businessName,
        String lane,
        Tenancy tenancy,
        String licenceHolderName,
        String rentedToName,
        int staffCount) {
}
