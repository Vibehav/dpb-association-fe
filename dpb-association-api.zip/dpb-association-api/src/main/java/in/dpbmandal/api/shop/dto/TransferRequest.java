package in.dpbmandal.api.shop.dto;

import in.dpbmandal.api.person.dto.NewPersonRequest;
import jakarta.validation.Valid;

import java.time.LocalDate;
import java.util.UUID;

/** Transfer the licence to an existing or new holder. tillDate defaults to today. */
public record TransferRequest(
        UUID existingPersonId,
        @Valid NewPersonRequest newPerson,
        LocalDate tillDate) {
}
