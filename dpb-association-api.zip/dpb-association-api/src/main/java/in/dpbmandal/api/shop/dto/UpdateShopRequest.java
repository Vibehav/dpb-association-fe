package in.dpbmandal.api.shop.dto;

import in.dpbmandal.api.shop.enums.Tenancy;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record UpdateShopRequest(
        @NotBlank String shopNumber,
        @NotBlank String businessName,
        String lane,
        @NotNull Tenancy tenancy) {
}
