package in.dpbmandal.api.shop.entity;

import in.dpbmandal.api.common.AuditableEntity;
import in.dpbmandal.api.shop.enums.Tenancy;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "shop")
public class Shop extends AuditableEntity {

    @Column(name = "shop_number", nullable = false, length = 40)
    private String shopNumber;

    @Column(name = "business_name", nullable = false, length = 200)
    private String businessName;

    @Column(length = 120)
    private String lane;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Tenancy tenancy;

    @Column(name = "former_holder_name", length = 150)
    private String formerHolderName;

    @Column(name = "former_holder_till")
    private LocalDate formerHolderTill;

    @Column(name = "deleted_at")
    private Instant deletedAt;
}
