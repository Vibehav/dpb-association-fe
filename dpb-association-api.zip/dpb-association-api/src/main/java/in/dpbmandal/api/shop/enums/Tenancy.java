package in.dpbmandal.api.shop.enums;

public enum Tenancy {
    OWNER_RUN,
    RENTED_OUT
}
