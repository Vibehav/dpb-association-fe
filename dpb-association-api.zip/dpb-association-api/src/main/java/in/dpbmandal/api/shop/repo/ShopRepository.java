package in.dpbmandal.api.shop.repo;

import in.dpbmandal.api.shop.entity.Shop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ShopRepository extends JpaRepository<Shop, UUID> {

    Optional<Shop> findByIdAndDeletedAtIsNull(UUID id);

    boolean existsByShopNumberIgnoreCaseAndDeletedAtIsNull(String shopNumber);

    boolean existsByShopNumberIgnoreCaseAndDeletedAtIsNullAndIdNot(String shopNumber, UUID id);

    /**
     * Page of active shop ids matching the (already lowercased) search pattern and lane.
     * Pass null for {@code q}/{@code lane} to skip that filter. Search covers shop number,
     * business name, and any linked person's name/phone.
     */
    @Query(value = """
            select s.id from shop s
            where s.deleted_at is null
              and (:lane is null or lower(s.lane) = :lane)
              and (:q is null
                   or lower(s.shop_number) like :q
                   or lower(s.business_name) like :q
                   or exists (select 1 from shop_link l
                                join person p on p.id = l.person_id
                              where l.shop_id = s.id and l.deleted_at is null and p.deleted_at is null
                                and (lower(p.name) like :q or p.phone like :q)))
            order by s.created_at desc
            limit :size offset :offset
            """, nativeQuery = true)
    List<UUID> searchShopIds(@Param("q") String q, @Param("lane") String lane,
                             @Param("size") int size, @Param("offset") int offset);

    @Query(value = """
            select count(*) from shop s
            where s.deleted_at is null
              and (:lane is null or lower(s.lane) = :lane)
              and (:q is null
                   or lower(s.shop_number) like :q
                   or lower(s.business_name) like :q
                   or exists (select 1 from shop_link l
                                join person p on p.id = l.person_id
                              where l.shop_id = s.id and l.deleted_at is null and p.deleted_at is null
                                and (lower(p.name) like :q or p.phone like :q)))
            """, nativeQuery = true)
    long countSearch(@Param("q") String q, @Param("lane") String lane);
}
