package in.dpbmandal.api.shop.service;

import in.dpbmandal.api.common.PagedResponse;
import in.dpbmandal.api.common.exception.ApiException;
import in.dpbmandal.api.link.entity.ShopLink;
import in.dpbmandal.api.link.enums.LinkRole;
import in.dpbmandal.api.link.repo.ShopLinkRepository;
import in.dpbmandal.api.link.service.ShopLinkService;
import in.dpbmandal.api.person.entity.Person;
import in.dpbmandal.api.person.repo.PersonRepository;
import in.dpbmandal.api.person.service.PersonCreationService;
import in.dpbmandal.api.shop.dto.PersonAtShopResponse;
import in.dpbmandal.api.shop.dto.RegisterShopRequest;
import in.dpbmandal.api.shop.dto.ShopDetailResponse;
import in.dpbmandal.api.shop.dto.ShopListItemResponse;
import in.dpbmandal.api.shop.dto.TransferRequest;
import in.dpbmandal.api.shop.dto.UpdateShopRequest;
import in.dpbmandal.api.shop.entity.Shop;
import in.dpbmandal.api.shop.repo.ShopRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ShopService {

    private static final int MAX_PAGE_SIZE = 100;

    private final ShopRepository shopRepo;
    private final ShopLinkRepository linkRepo;
    private final PersonRepository personRepo;
    private final PersonCreationService personService;
    private final ShopLinkService linkService;

    // ---- register -----------------------------------------------------------

    @Transactional
    public ShopDetailResponse register(RegisterShopRequest req) {
        String shopNumber = req.shopNumber().trim();
        if (shopRepo.existsByShopNumberIgnoreCaseAndDeletedAtIsNull(shopNumber)) {
            throw ApiException.conflict("duplicate_shop_number", "A shop with this number already exists");
        }
        Shop shop = new Shop();
        shop.setShopNumber(shopNumber);
        shop.setBusinessName(req.businessName().trim());
        shop.setLane(req.lane());
        shop.setTenancy(req.tenancy());
        shop = shopRepo.save(shop);

        Person owner = personService.resolve(req.owner().existingPersonId(), req.owner().newPerson());
        linkService.createLink(shop.getId(), owner.getId(), LinkRole.OWNER);

        return detail(shop.getId());
    }

    // ---- read ---------------------------------------------------------------

    @Transactional(readOnly = true)
    public PagedResponse<ShopListItemResponse> list(String query, String lane, int page, int size) {
        int safeSize = Math.min(Math.max(size, 1), MAX_PAGE_SIZE);
        int safePage = Math.max(page, 0);
        String q = (query == null || query.isBlank()) ? null : "%" + query.trim().toLowerCase() + "%";
        String laneParam = (lane == null || lane.isBlank()) ? null : lane.trim().toLowerCase();

        long total = shopRepo.countSearch(q, laneParam);
        List<UUID> ids = shopRepo.searchShopIds(q, laneParam, safeSize, safePage * safeSize);
        if (ids.isEmpty()) {
            return PagedResponse.of(List.of(), safePage, safeSize, total);
        }

        Map<UUID, Shop> shopsById = shopRepo.findAllById(ids).stream()
                .collect(Collectors.toMap(Shop::getId, Function.identity()));
        List<ShopLink> links = linkRepo.findByShopIdInAndDeletedAtIsNull(ids);
        Map<UUID, String> personNames = loadPersonNames(links.stream().map(ShopLink::getPersonId).toList());
        Map<UUID, List<ShopLink>> linksByShop = links.stream()
                .collect(Collectors.groupingBy(ShopLink::getShopId));

        List<ShopListItemResponse> items = ids.stream()
                .map(shopsById::get)
                .map(s -> toListItem(s, linksByShop.getOrDefault(s.getId(), List.of()), personNames))
                .toList();
        return PagedResponse.of(items, safePage, safeSize, total);
    }

    @Transactional(readOnly = true)
    public ShopDetailResponse detail(UUID shopId) {
        Shop shop = getActiveShop(shopId);
        List<ShopLink> links = linkRepo.findByShopIdAndDeletedAtIsNull(shopId);
        Map<UUID, Person> personsById = personRepo.findAllById(links.stream().map(ShopLink::getPersonId).toList())
                .stream().collect(Collectors.toMap(Person::getId, Function.identity()));

        List<PersonAtShopResponse> people = links.stream()
                .sorted(Comparator.comparingInt(l -> l.getRole().ordinal())) // OWNER, RENTER, STAFF
                .map(l -> {
                    Person p = personsById.get(l.getPersonId());
                    return new PersonAtShopResponse(l.getId(), l.getPersonId(),
                            p != null ? p.getName() : null,
                            p != null ? p.getPhone() : null,
                            l.getRole());
                })
                .toList();

        return new ShopDetailResponse(shop.getId(), shop.getShopNumber(), shop.getBusinessName(),
                shop.getLane(), shop.getTenancy(), shop.getFormerHolderName(), shop.getFormerHolderTill(), people);
    }

    // ---- update / delete ----------------------------------------------------

    @Transactional
    public ShopDetailResponse update(UUID shopId, UpdateShopRequest req) {
        Shop shop = getActiveShop(shopId);
        String shopNumber = req.shopNumber().trim();
        if (shopRepo.existsByShopNumberIgnoreCaseAndDeletedAtIsNullAndIdNot(shopNumber, shopId)) {
            throw ApiException.conflict("duplicate_shop_number", "A shop with this number already exists");
        }
        shop.setShopNumber(shopNumber);
        shop.setBusinessName(req.businessName().trim());
        shop.setLane(req.lane());
        shop.setTenancy(req.tenancy());
        return detail(shop.getId());
    }

    @Transactional
    public void softDelete(UUID shopId) {
        Shop shop = getActiveShop(shopId);
        shop.setDeletedAt(Instant.now());
        // Option A: unlink everyone; anyone left with no links becomes "No shop linked".
        for (ShopLink link : linkRepo.findByShopIdAndDeletedAtIsNull(shopId)) {
            linkService.softRemove(link);
        }
    }

    // ---- transfer -----------------------------------------------------------

    @Transactional
    public ShopDetailResponse transfer(UUID shopId, TransferRequest req) {
        Shop shop = getActiveShop(shopId);
        ShopLink currentOwnerLink = linkRepo.findByShopIdAndRoleAndDeletedAtIsNull(shopId, LinkRole.OWNER)
                .orElseThrow(() -> ApiException.conflict("no_owner", "This shop has no licence holder to transfer"));
        Person oldOwner = personRepo.findById(currentOwnerLink.getPersonId()).orElse(null);

        Person newHolder = personService.resolve(req.existingPersonId(), req.newPerson());
        if (newHolder.getId().equals(currentOwnerLink.getPersonId())) {
            throw ApiException.badRequest("already_owner", "That member is already the licence holder");
        }
        // If the new holder is currently a renter/staff of this shop, free that link first
        // so the unique (person, shop) constraint is not violated by the new owner link.
        linkRepo.findByShopIdAndPersonIdAndDeletedAtIsNull(shopId, newHolder.getId())
                .ifPresent(linkService::softRemove);

        linkService.softRemove(currentOwnerLink);
        // Flush the removals (UPDATEs) before inserting the new owner: Hibernate would
        // otherwise order the INSERT ahead of the UPDATEs and briefly have two active
        // owners / a duplicate (person, shop), tripping the partial unique indexes.
        linkRepo.flush();
        linkService.createLink(shopId, newHolder.getId(), LinkRole.OWNER);

        shop.setFormerHolderName(oldOwner != null ? oldOwner.getName() : null);
        shop.setFormerHolderTill(req.tillDate() != null ? req.tillDate() : LocalDate.now());
        return detail(shopId);
    }

    // ---- helpers ------------------------------------------------------------

    private Shop getActiveShop(UUID shopId) {
        return shopRepo.findByIdAndDeletedAtIsNull(shopId)
                .orElseThrow(() -> ApiException.notFound("shop_not_found", "Shop not found"));
    }

    private Map<UUID, String> loadPersonNames(List<UUID> personIds) {
        return personRepo.findAllById(personIds).stream()
                .collect(Collectors.toMap(Person::getId, Person::getName));
    }

    private ShopListItemResponse toListItem(Shop shop, List<ShopLink> links, Map<UUID, String> personNames) {
        String owner = null;
        String renter = null;
        int staff = 0;
        for (ShopLink l : links) {
            switch (l.getRole()) {
                case OWNER -> owner = personNames.get(l.getPersonId());
                case RENTER -> renter = personNames.get(l.getPersonId());
                case STAFF -> staff++;
            }
        }
        return new ShopListItemResponse(shop.getId(), shop.getShopNumber(), shop.getBusinessName(),
                shop.getLane(), shop.getTenancy(), owner, renter, staff);
    }
}
