-- Bootstrap the first admin so the committee is not empty. PIN is not set here;
-- Ishwar sets it on first sign-in via the OTP (first-login) flow. Changeable later.
insert into committee_user (id, phone, name, role, pin_set, token_version,
                            failed_pin_attempts, active, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000001',
        '8451963620', 'Ishwar', 'ADMIN',
        false, 0, 0, true, now(), now());
