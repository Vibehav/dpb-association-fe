package in.dpbmandal.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DpbAssociationApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
